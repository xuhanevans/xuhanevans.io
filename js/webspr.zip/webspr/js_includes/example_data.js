var shuffleSequence = seq("intro", "practice", rshuffle("f", rshuffle("s1", "s2")), "break", rshuffle("q1", "q2"), "outro");
var practiceItemTypes = ["practice"];

var ds = DashedSentence;
var q = AcceptabilityJudgment;

var defaults = [DashedSentence, { mode: "self-paced reading" },AcceptabilityJudgment, {q: "How was it?", as: ["1", "2", "3", "4", "5", "6", "7"], presentAsScale: true}];

var items = [

["intro", Message, {html: "Blah blah blah..."}],
["break", Message, {html: "Foo blah blah blah..."}],

["practice", ds, {s: "Here's a practice sentence."}],
["practice", ds, {s: "Here's another practice sentence."}],
["practice", ds, {s: "Yet another practice sentence."}],

[["s1",1], ds, {s: "The journalist interviewed an actress who he knew to be shy of publicity after meeting on a previous occasion"}],
[["s2",1], ds, {s: "The journalist interviewed an actress who after meeting on a previous occasion he knew to be shy of publicity"}],
[["q1", 2], q, {s: "Which actress did the journalist interview after meeting her PA on a previous occasion?"}],
[["q2", 2], q, {s: "Which actress did the journalist interview her husband after meeting on a previous occasion?"}],

[["s1",3], ds, {s: "The teacher helped struggling students who he encouraged to succeed without treating like idiots"}],
[["s2",3], ds, {s: "The teacher helped struggling students who without treating like idiots he encouraged to succeed"}],
[["q1",4], q, {s: "Which struggling students did the teacher encourage to succeed without treating their friends like idiots?"}],
[["q2",4], q, {s: "Which struggling students did the teacher encourage their friends to succeed without treating like idiots?"}],

["f", ds, {s: "The foreign spy that encoded the top-secret messages was given a new mission that required going to Japan."}],
["f", ds, {s: "The receptionist that the real estate company just hired immediately familiarized herself with all the phone numbers of their clients."}],
["f", ds, {s: "Every delicious chocolate cake that the kind baker is making will be one of a kind."}],
["f", ds, {s: "The gangsters that the local police officers tracked for years were represented by an inexperienced lawyer."}],
["f", ds, {s: "The woman that John had seen in the subway bought himself a pair of stunning shoes that cost a fortune."}],
["f", ds, {s: "If the award-winning chef had entered this competition, he surely would have won first prize."}],
["f", ds, {s: "If the organized secretary had filed the documents when she first received them, they are easy to find."}],
["f", ds, {s: "If the homemade beer had been left to ferment more, it would have been drinkable."}],

["outro", Message, {html: "You're done! (Press any button to proceed to submission)"}]

];
